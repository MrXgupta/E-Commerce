<footer>
    <h5>All Right are Reserved @2024</h5>
</footer>


</body>
</html> 
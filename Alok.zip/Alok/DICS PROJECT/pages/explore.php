<?php
include("../header.php");
include("../config/dao.php");
?>

<div class="random">
    <?php random_products();?>
</div>

<div class="warning msg"></div>